package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SimpleFormPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private By messageInput = By.cssSelector("input#user-message");
    private By getCheckedValueButton = By.id("showInput");
    private By displayedMessage = By.cssSelector("p#message");

    // Constructor
    public SimpleFormPage(WebDriver driver) {

        this.driver = driver;

        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        // Wait until the page is completely loaded
        wait.until(webDriver ->
                ((JavascriptExecutor) webDriver)
                        .executeScript("return document.readyState")
                        .equals("complete"));

        // Wait for the input field to appear
        wait.until(
                ExpectedConditions.presenceOfElementLocated(messageInput)
        );

        /*
         * TestMu AI Simple Form page is React-rendered.
         * The HTML can appear before the React event handlers
         * are completely attached.
         *
         * Small wait here prevents sendKeys() from happening
         * before the React component is hydrated.
         */
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // Enter message
    public void enterMessage(String message) {

        WebElement input = wait.until(
                ExpectedConditions.elementToBeClickable(messageInput)
        );

        input.click();
        input.clear();
        input.sendKeys(message);

        // Verify that Selenium actually entered the text
        wait.until(driver -> {
            String value = input.getAttribute("value");
            return message.equals(value);
        });
    }

    // Click Get Checked Value
    public void clickGetCheckedValue() {

        WebElement button = wait.until(
                ExpectedConditions.elementToBeClickable(getCheckedValueButton)
        );

        button.click();
    }

    // Get displayed message
    public String getDisplayedMessage() {

        WebElement output = wait.until(
                ExpectedConditions.visibilityOfElementLocated(displayedMessage)
        );

        return wait.until(driver -> {

            String text = output.getText();

            if (text != null && !text.trim().isEmpty()) {
                return text.trim();
            }

            return null;
        });
    }
}