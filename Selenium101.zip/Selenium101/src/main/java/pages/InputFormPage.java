package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class InputFormPage {

    private WebDriver driver;

    private By name =
            By.id("name");

    private By email =
            By.id("inputEmail4");

    private By password =
            By.id("inputPassword4");

    private By company =
            By.id("company");

    private By website =
            By.id("websitename");

    private By country =
            By.name("country");

    private By city =
            By.id("inputCity");

    private By address1 =
            By.id("inputAddress1");

    private By address2 =
            By.id("inputAddress2");

    private By state =
            By.id("inputState");

    private By zip =
            By.id("inputZip");

    private By submitButton =
            By.xpath("//button[contains(normalize-space(),'Submit')]");

    private By successMessage =
            By.xpath(
                "//*[contains(normalize-space(),'Thanks for contacting us, we will get back to you shortly.')]"
            );

    public InputFormPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickSubmit() {

        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(
                ExpectedConditions.elementToBeClickable(submitButton)
        ).click();
    }

    public String getNameValidationMessage() {

        return driver.findElement(name)
                .getAttribute("validationMessage");
    }

    public void enterName(String value) {

        driver.findElement(name).clear();
        driver.findElement(name).sendKeys(value);
    }

    public void enterEmail(String value) {

        driver.findElement(email).clear();
        driver.findElement(email).sendKeys(value);
    }

    public void enterPassword(String value) {

        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(value);
    }

    public void enterCompany(String value) {

        driver.findElement(company).clear();
        driver.findElement(company).sendKeys(value);
    }

    public void enterWebsite(String value) {

        driver.findElement(website).clear();
        driver.findElement(website).sendKeys(value);
    }

    public void selectCountry(String countryName) {

        Select select =
                new Select(driver.findElement(country));

        select.selectByVisibleText(countryName);
    }

    public void enterCity(String value) {

        driver.findElement(city).clear();
        driver.findElement(city).sendKeys(value);
    }

    public void enterAddress1(String value) {

        driver.findElement(address1).clear();
        driver.findElement(address1).sendKeys(value);
    }

    public void enterAddress2(String value) {

        driver.findElement(address2).clear();
        driver.findElement(address2).sendKeys(value);
    }

    public void enterState(String value) {

        driver.findElement(state).clear();
        driver.findElement(state).sendKeys(value);
    }

    public void enterZip(String value) {

        driver.findElement(zip).clear();
        driver.findElement(zip).sendKeys(value);
    }

    public boolean isSuccessMessageDisplayed() {

        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(10));

        try {

            return wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            successMessage
                    )
            ).isDisplayed();

        } catch (Exception e) {

            return false;
        }
    }
}