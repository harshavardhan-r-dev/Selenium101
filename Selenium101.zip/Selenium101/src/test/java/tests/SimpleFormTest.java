package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.PlaygroundPage;
import pages.SimpleFormPage;

public class SimpleFormTest extends BaseTest {

    @Test
    public void verifySimpleFormMessage() {

        PlaygroundPage playground =
                new PlaygroundPage(driver);

        SimpleFormPage simpleForm =
                playground.clickSimpleFormDemo();

        Assert.assertTrue(
                driver.getCurrentUrl().contains("simple-form-demo"),
                "URL does not contain simple-form-demo"
        );

        String message = "Welcome to TestMu AI";

        simpleForm.enterMessage(message);

        simpleForm.clickGetCheckedValue();

        String actualMessage =
                simpleForm.getDisplayedMessage();

        Assert.assertEquals(
                actualMessage,
                message,
                "Displayed message does not match entered message"
        );
    }
}