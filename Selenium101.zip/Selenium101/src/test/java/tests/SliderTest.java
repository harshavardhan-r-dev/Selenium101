package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.PlaygroundPage;
import pages.SliderPage;

public class SliderTest extends BaseTest {

    @Test
    public void moveSliderFrom15To95() {

        PlaygroundPage playground = new PlaygroundPage(driver);

        SliderPage sliderPage = playground.clickDragDropSliders();

        sliderPage.moveSliderTo95();

        String actualValue = sliderPage.getSliderValue();

        Assert.assertEquals(
                actualValue,
                "95",
                "Slider value is not 95"
        );
    }
}