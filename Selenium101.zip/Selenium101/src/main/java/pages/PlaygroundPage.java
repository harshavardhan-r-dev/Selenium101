package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PlaygroundPage {

    private WebDriver driver;

    private By simpleFormDemo =
            By.linkText("Simple Form Demo");

    private By dragDropSliders =
            By.linkText("Drag & Drop Sliders");

    private By inputFormSubmit =
            By.linkText("Input Form Submit");

    public PlaygroundPage(WebDriver driver) {
        this.driver = driver;
    }

    public SimpleFormPage clickSimpleFormDemo() {

        driver.findElement(simpleFormDemo).click();

        return new SimpleFormPage(driver);
    }

    public SliderPage clickDragDropSliders() {

        driver.findElement(dragDropSliders).click();

        return new SliderPage(driver);
    }

    public InputFormPage clickInputFormSubmit() {

        driver.findElement(inputFormSubmit).click();

        return new InputFormPage(driver);
    }
}