package base;

import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import utils.ConfigReader;

public class BaseTest {

    protected WebDriver driver;

    @BeforeMethod
    @Parameters({"browser", "platform"})
    public void setUp(String browser, String platform) throws Exception {

        String username = System.getenv("LT_USERNAME");
        String accessKey = System.getenv("LT_ACCESS_KEY");

        if (username == null || accessKey == null) {
            throw new RuntimeException(
                "LT_USERNAME or LT_ACCESS_KEY is not set"
            );
        }

        String hubURL =
            "https://" + username + ":" + accessKey
            + "@hub.lambdatest.com/wd/hub";

        HashMap<String, Object> ltOptions = new HashMap<>();

        ltOptions.put("build", "Selenium101 Certification");
        ltOptions.put("name", browser + " - " + platform);

        // Required assignment capabilities
        ltOptions.put("video", true);
        ltOptions.put("visual", true);
        ltOptions.put("network", true);
        ltOptions.put("console", true);

        ltOptions.put("w3c", true);

        if (browser.equalsIgnoreCase("chrome")) {

            ChromeOptions options = new ChromeOptions();

            options.setPlatformName(platform);
            options.setBrowserVersion("latest");

            options.setCapability(
                "LT:Options",
                ltOptions
            );

            driver = new RemoteWebDriver(
                new URL(hubURL),
                options
            );

        } else if (browser.equalsIgnoreCase("safari")) {

            SafariOptions options = new SafariOptions();

            options.setPlatformName(platform);
            options.setBrowserVersion("latest");

            options.setCapability(
                "LT:Options",
                ltOptions
            );

            driver = new RemoteWebDriver(
                new URL(hubURL),
                options
            );

        } else {

            throw new RuntimeException(
                "Unsupported browser: " + browser
            );
        }

        driver.manage()
              .timeouts()
              .implicitlyWait(Duration.ofSeconds(10));

        driver.manage()
              .window()
              .maximize();

        driver.get(
            ConfigReader.getProperty("url")
        );
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}