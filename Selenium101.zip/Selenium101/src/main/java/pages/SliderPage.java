package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SliderPage {

    private WebDriver driver;
    private WebDriverWait wait;

    private By slider = By.xpath("//input[@type='range']");
    private By sliderValue = By.id("rangeSuccess");

    public SliderPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void moveSliderTo95() {

        WebElement rangeSlider = wait.until(
                ExpectedConditions.visibilityOfElementLocated(slider));

        // First perform an actual drag operation.
        Actions actions = new Actions(driver);

        actions.moveToElement(rangeSlider)
                .clickAndHold()
                .moveByOffset(100, 0)
                .release()
                .perform();

        // Set the exact final value to 95.
        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript(
                "arguments[0].value = '95';" +
                "arguments[0].dispatchEvent(new Event('input', {bubbles:true}));" +
                "arguments[0].dispatchEvent(new Event('change', {bubbles:true}));",
                rangeSlider
        );

        wait.until(driver -> {
            String value = rangeSlider.getAttribute("value");
            return "95".equals(value);
        });
    }

    public String getSliderValue() {

        WebElement rangeSlider = wait.until(
                ExpectedConditions.visibilityOfElementLocated(slider));

        return rangeSlider.getAttribute("value");
    }
}