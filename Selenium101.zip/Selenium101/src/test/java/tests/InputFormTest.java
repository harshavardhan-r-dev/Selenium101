package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.InputFormPage;
import pages.PlaygroundPage;

public class InputFormTest extends BaseTest {

    @Test
    public void submitInputForm() {

        // Open Input Form Submit page
        PlaygroundPage playground = new PlaygroundPage(driver);

        InputFormPage inputForm =
                playground.clickInputFormSubmit();

        // -------------------------------------------------
        // 1. Submit empty form
        // -------------------------------------------------

        inputForm.clickSubmit();

        // Get browser validation message
        String validationMessage =
                inputForm.getNameValidationMessage();

        // Normalize browser-specific validation messages
        String normalizedMessage = validationMessage
                .toLowerCase()
                .replace("please ", "")
                .replace("fill out", "fill in")
                .replace(".", "")
                .trim();

        Assert.assertEquals(
                normalizedMessage,
                "fill in this field",
                "Incorrect validation message: " + validationMessage
        );

        // -------------------------------------------------
        // 2. Fill all form fields
        // -------------------------------------------------

        inputForm.enterName("Harshavardhan");

        inputForm.enterEmail(
                "harshavardhan@example.com"
        );

        inputForm.enterPassword(
                "Password123"
        );

        inputForm.enterCompany(
                "Test Company"
        );

        inputForm.enterWebsite(
                "https://example.com"
        );

        // Select country using visible text
        inputForm.selectCountry(
                "United States"
        );

        inputForm.enterCity(
                "New York"
        );

        inputForm.enterAddress1(
                "123 Main Street"
        );

        inputForm.enterAddress2(
                "Apartment 101"
        );

        inputForm.enterState(
                "New York"
        );

        inputForm.enterZip(
                "10001"
        );

        // -------------------------------------------------
        // 3. Submit completed form
        // -------------------------------------------------

        inputForm.clickSubmit();

        // -------------------------------------------------
        // 4. Validate success message
        // -------------------------------------------------

        Assert.assertTrue(
                inputForm.isSuccessMessageDisplayed(),
                "Success message was not displayed"
        );
    }
}